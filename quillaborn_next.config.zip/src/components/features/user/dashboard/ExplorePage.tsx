"use client";

import ExploreContent from '@/components/features/explore/ExploreContent';

export default function ExplorePage() {
  return (
    <div className="relative">
      <ExploreContent inDashboard />
    </div>
  );
}