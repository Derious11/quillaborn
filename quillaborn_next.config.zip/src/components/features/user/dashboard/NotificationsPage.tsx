export default function NotificationsPage() {
  return (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-lg p-6">
        <p className="text-gray-400">No new notifications</p>
      </div>
    </div>
  );
} 