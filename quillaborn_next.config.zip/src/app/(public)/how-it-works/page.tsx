import HowItWorksPage from "@/components/features/public/How";

export const metadata = {
  title: "How – Quillaborn",
  description: "How page for the Quillaborn platform.",
};

export default function How() {
  return <HowItWorksPage />;
}
