import FileManager from "@/components/projects/FileManager";
import UpdatesFeed from "@/components/projects/FileManager";

export default function UpdatesPage() {
  return <FileManager />;
}
