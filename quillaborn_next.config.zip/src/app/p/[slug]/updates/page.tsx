import UpdatesFeed from "@/components/projects/UpdatesFeed";

export default function UpdatesPage() {
  return <UpdatesFeed />;
}
