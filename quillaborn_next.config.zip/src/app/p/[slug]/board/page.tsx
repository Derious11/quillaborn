import Board from "@/components/projects/Board";

export default function BoardPage() {
  return <Board />;
}
