import ChatBox from "@/components/projects/ChatBox";
import UpdatesFeed from "@/components/projects/ChatBox";

export default function UpdatesPage() {
  return <ChatBox />;
}
