import {
  Sparkles,
  Wrench,
  Mail,
  Lightbulb,
  Users,
  HeartHandshake,
} from "lucide-react";
import { useState } from "react";
import Header from "../components/Header";
import WaitlistModal from "../components/WaitlistModal";

export default function ContactSupportPage() {
  const [showBugForm, setShowBugForm] = useState(false);
  const [showFeatureForm, setShowFeatureForm] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [showWaitlistModal, setShowWaitlistModal] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (type) => {
    const table = type === "bug" ? "Bugs" : "Features";

    await fetch(`https://api.airtable.com/v0/${import.meta.env.VITE_AIRTABLE_BASE_ID}/${table}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_AIRTABLE_API_KEY}`,
      },
      body: JSON.stringify({
        fields: {
          Name: formData.name,
          Email: formData.email,
          Message: formData.message,
          Type: type,
        },
      }),
    });

    setFormData({ name: "", email: "", message: "" });
    setShowBugForm(false);
    setShowFeatureForm(false);
    setSuccessMessage(type === "bug" ? "🐞 Bug reported successfully!" : "💡 Feature submitted successfully!");
    setShowSuccess(true);

    setTimeout(() => {
      setShowSuccess(false);
      setSuccessMessage("");
    }, 4000);
  };

  return (
    <div className="relative min-h-screen text-white">
      <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 via-gray-900 to-gray-950"></div>
      <div className="absolute inset-0 opacity-50 bg-gray-900"></div>
      <div className="absolute top-20 left-10 w-20 h-20 bg-green-500/10 rounded-full animate-float hidden lg:block"></div>
      <div className="absolute top-40 right-20 w-12 h-12 bg-green-400/20 rounded-lg rotate-45 animate-float hidden lg:block"></div>
      <div className="absolute bottom-20 left-1/4 w-8 h-8 bg-green-300/30 rounded-full animate-float hidden lg:block"></div>

      <div className="relative z-10">
        <Header onJoinWaitlist={() => setShowWaitlistModal(true)} />
        <WaitlistModal show={showWaitlistModal} onClose={() => setShowWaitlistModal(false)} />

        <main className="px-6 py-16 max-w-3xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-heading font-bold text-white flex justify-center items-center gap-3">
              <Mail className="w-6 h-6 text-green-400" /> Contact & Support
            </h1>
            <p className="text-lg text-gray-300">
              Need help? Have feedback? Just want to say hi? We’re creators too—and we’re here to support you every step of the way.
            </p>
          </div>

          <section className="space-y-8 text-gray-300">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Wrench className="w-5 h-5 text-green-400" /> Get Support
              </h2>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>📧 Email: <a href="mailto:support@quillaborn.com" className="text-green-400 underline">support@quillaborn.com</a></li>
                <li>💬 Discord Community: <span className="text-gray-100">Join Our Server</span></li>
                <li>🐞 Report a Bug: <button onClick={() => setShowBugForm(true)} className="ml-2 text-green-400 underline">Open Form</button></li>
                <li>❓ Help Docs & FAQ: <span className="text-gray-400 italic">Coming Soon</span></li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-green-400" /> Suggest a Feature
              </h2>
              <p className="mb-1">Got an idea to improve Quillaborn? We’d love to hear it.</p>
              <button onClick={() => setShowFeatureForm(true)} className="text-green-400 underline">👉 Submit a Feature Request</button>
              <p className="text-sm text-gray-400">Our roadmap is shaped by our community—your voice matters.</p>
            </div>

            {(showBugForm || showFeatureForm) && (
              <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center px-4">
                <div className="bg-gray-900 text-white rounded-2xl p-6 max-w-md w-full shadow-xl relative animate-fadeIn">
                  <button
                    onClick={() => {
                      setShowBugForm(false);
                      setShowFeatureForm(false);
                    }}
                    className="absolute top-4 right-4 text-gray-400 hover:text-white"
                  >
                    ✕
                  </button>
                  <h3 className="text-2xl font-bold mb-4 text-green-400">
                    {showBugForm ? "🐞 Report a Bug" : "💡 Feature Request"}
                  </h3>
                  <div className="space-y-3">
                    <input type="text" name="name" placeholder="Your name" onChange={handleChange} value={formData.name} className="w-full p-3 rounded bg-gray-800 border border-gray-700" />
                    <input type="email" name="email" placeholder="Your email" onChange={handleChange} value={formData.email} className="w-full p-3 rounded bg-gray-800 border border-gray-700" />
                    <textarea name="message" placeholder="Describe the issue or feature..." onChange={handleChange} value={formData.message} rows={4} className="w-full p-3 rounded bg-gray-800 border border-gray-700"></textarea>
                    <div className="flex justify-end gap-3 pt-2">
                      <button onClick={() => { setShowBugForm(false); setShowFeatureForm(false); }} className="px-4 py-2 rounded bg-gray-600 hover:bg-gray-500 text-white">Cancel</button>
                      <button onClick={() => handleSubmit(showBugForm ? "bug" : "feature")} className="px-4 py-2 rounded bg-green-500 hover:bg-green-600 text-black font-semibold">Submit</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {showSuccess && (
              <div className="fixed bottom-6 right-6 bg-green-500 text-gray-900 px-6 py-4 rounded-xl shadow-lg font-medium text-sm z-50 animate-fadeInUp">
                {successMessage}
              </div>
            )}

            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Users className="w-5 h-5 text-green-400" /> Press / Partnerships / Licensing
              </h2>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Partnerships & Press: <a href="mailto:partners@quillaborn.com" className="text-green-400 underline">partners@quillaborn.com</a></li>
                <li>Business & Licensing: <a href="mailto:team@quillaborn.com" className="text-green-400 underline">team@quillaborn.com</a></li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <HeartHandshake className="w-5 h-5 text-green-400" /> Community Comes First
              </h2>
              <p>Quillaborn is built with creators, not corporations. We aim to respond to all messages within 48 hours, but please be kind—we’re a small team with big dreams.</p>
              <p className="mt-2">Thanks for helping us build a more collaborative, respectful creative world.</p>
            </div>
          </section>
        </main>

        <footer className="bg-gray-950 py-12 border-t border-gray-800">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="flex items-center space-x-2 mb-4 md:mb-0">
                <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-gray-900" />
                </div>
                <span className="text-xl font-bold">Quillaborn</span>
              </div>
              <div className="text-gray-400 text-sm">© 2025 Quillaborn. Built for creators, by creators.</div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}